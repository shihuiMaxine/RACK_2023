from rack.core.CodeTokenProvider import CodeTokenProvider
def main():
    # query = "how to send email in python?"
    query = input("Please enter query: ")

    provider=CodeTokenProvider(query)

    results = ""
    results = provider.recommendRelevantAPIs("all")
    var4 = results


    for i in var4:
        atoken =i


        print(str(atoken.token) + " " +
            str(atoken.KACScore) + " " +
            str(atoken.KPACScore) + " " +
            str(atoken.KKCScore) + " " +
            str(atoken.totalScore))



