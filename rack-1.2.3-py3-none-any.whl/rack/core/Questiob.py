from rack.core. CodeTokenProvider import CodeTokenProvider
#?
# text1 = 'questions1.txt'
# file = open('qlink2', 'r')
# with open(text1, 'r') as file:
#     for line in file:
#         print(type(line))
#         query = line

#         provider = CodeTokenProvider(query)


#         results = provider.recommendRelevantAPIs("all")
#         print(results)
#         print(type(results))
#         print(results[:10])