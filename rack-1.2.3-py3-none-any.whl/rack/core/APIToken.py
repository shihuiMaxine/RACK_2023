
class APIToken :
    token=""
    KACScore = 0
    KKCScore = 0
    KPACScore = 0
    totalScore = 0

